'use client'

import { motion } from 'framer-motion'

export function HexagonShape() {
  return (
    <motion.div
      className="w-48 h-48 relative"
      animate={{
        rotate: [0, 10, 0],
        scale: [1, 1.05, 1],
      }}
      transition={{
        duration: 8,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-green-400 via-orange-500 to-red-500 rounded-lg transform rotate-45 blur-sm" />
    </motion.div>
  )
}

export function CircleShape() {
  return (
    <motion.div
      className="w-48 h-48 relative"
      animate={{
        scale: [1, 1.1, 1],
      }}
      transition={{
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      <div className="absolute inset-0 bg-gradient-conic from-pink-500 via-cyan-500 to-orange-500 rounded-full blur-sm" />
    </motion.div>
  )
}

export function ParallelShape() {
  return (
    <motion.div
      className="w-48 h-32 relative"
      animate={{
        rotate: [0, -10, 0],
      }}
      transition={{
        duration: 7,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      <div className="absolute inset-0 flex gap-4">
        <div className="w-1/2 h-full bg-gradient-to-b from-pink-500 to-cyan-500 rounded-lg transform -skew-x-12" />
        <div className="w-1/2 h-full bg-gradient-to-b from-cyan-500 to-pink-500 rounded-lg transform -skew-x-12" />
      </div>
    </motion.div>
  )
}

