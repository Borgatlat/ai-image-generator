'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { motion, AnimatePresence } from 'framer-motion'

interface FlashcardProps {
  front: string
  back: string
}

export function Flashcard({ front, back }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false)

  return (
    <div
      className="perspective-1000 w-full h-40 cursor-pointer"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <AnimatePresence initial={false} mode="wait">
        {!isFlipped ? (
          <motion.div
            key="front"
            initial={{ rotateY: 180 }}
            animate={{ rotateY: 0 }}
            exit={{ rotateY: -180 }}
            transition={{ duration: 0.3 }}
            className="absolute w-full h-full"
          >
            <Card className="w-full h-full p-6 bg-[#282a36] border-[#BD93F9] flex items-center justify-center text-center">
              <div className="text-[#F8F8F2] text-lg overflow-auto max-h-full">
                <span className="line-clamp-3">{front}</span>
              </div>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="back"
            initial={{ rotateY: -180 }}
            animate={{ rotateY: 0 }}
            exit={{ rotateY: 180 }}
            transition={{ duration: 0.3 }}
            className="absolute w-full h-full"
          >
            <Card className="w-full h-full p-6 bg-[#44475a] border-[#FF79C6] flex items-center justify-center text-center">
              <div className="text-[#F8F8F2] text-lg overflow-auto max-h-full">
                <span className="line-clamp-3">{back}</span>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

