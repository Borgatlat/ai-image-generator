'use client'

import { useEffect, useRef } from 'react'

interface Topic {
  id: string
  text: string
  color?: string
  children?: Topic[]
}

interface MindMapProps {
  data: Topic
}

export function MindMap({ data }: MindMapProps) {
  const svgRef = useRef<SVGSVGElement>(null)

  useEffect(() => {
    if (!svgRef.current) return

    const svg = svgRef.current
    const paths = svg.querySelectorAll('.connection-path')
    paths.forEach(path => path.remove())

    const centralNode = document.getElementById(data.id)
    if (!centralNode) return

    data.children?.forEach(branch => {
      const branchEl = document.getElementById(branch.id)
      if (!branchEl) return

      createCurvedPath(svg, centralNode, branchEl)

      branch.children?.forEach(topic => {
        const topicEl = document.getElementById(topic.id)
        if (!topicEl) return
        createCurvedPath(svg, branchEl, topicEl)

        topic.children?.forEach(subtopic => {
          const subtopicEl = document.getElementById(subtopic.id)
          if (!subtopicEl) return
          createCurvedPath(svg, topicEl, subtopicEl)
        })
      })
    })
  }, [data])

  function createCurvedPath(svg: SVGSVGElement, start: HTMLElement, end: HTMLElement) {
    const startRect = start.getBoundingClientRect()
    const endRect = end.getBoundingClientRect()
    const svgRect = svg.getBoundingClientRect()

    const startX = startRect.x - svgRect.x + startRect.width / 2
    const startY = startRect.y - svgRect.y + startRect.height / 2
    const endX = endRect.x - svgRect.x + endRect.width / 2
    const endY = endRect.y - svgRect.y + endRect.height / 2

    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
    path.classList.add('connection-path')

    const dx = endX - startX
    const dy = endY - startY
    const controlX = startX + dx / 2
    const controlY = startY + dy / 2

    path.setAttribute(
      'd',
      `M ${startX} ${startY} Q ${controlX} ${startY} ${controlX} ${controlY} T ${endX} ${endY}`
    )

    path.setAttribute('stroke', '#4B5563')
    path.setAttribute('stroke-width', '2')
    path.setAttribute('fill', 'none')

    svg.appendChild(path)
  }

  return (
    <div className="relative w-full min-h-[800px] p-8">
      <svg
        ref={svgRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ zIndex: 0 }}
      />
      <div className="relative flex flex-col items-center" style={{ zIndex: 1 }}>
        <div className="mb-12">
          <div
            id={data.id}
            className="bg-teal-500 text-black rounded-full p-6 w-40 h-40 flex items-center justify-center text-xl font-bold"
          >
            <span className="text-center break-words max-w-[90%] line-clamp-3">
              {data.text}
            </span>
          </div>
        </div>
        <div className="flex justify-center gap-16 flex-wrap">
          {data.children?.map((branch, index) => (
            <div key={branch.id} className="flex flex-col items-center gap-8">
              <div
                id={branch.id}
                className={`bg-white text-black rounded-lg p-4 w-48 border-l-4 border-${branch.color} shadow-lg`}
              >
                <span className="block text-center break-words line-clamp-2">
                  {branch.text}
                </span>
              </div>
              <div className="grid gap-4 grid-cols-2">
                {branch.children?.map(topic => (
                  <div key={topic.id} className="flex flex-col items-center gap-4">
                    <div
                      id={topic.id}
                      className={`bg-white text-black rounded-lg p-3 w-40 border-l-4 border-${topic.color} shadow-lg`}
                    >
                      <span className="block text-center break-words line-clamp-2 text-sm">
                        {topic.text}
                      </span>
                    </div>
                    {topic.children?.map(subtopic => (
                      <div
                        key={subtopic.id}
                        id={subtopic.id}
                        className={`bg-white text-black rounded-lg p-2 w-36 border-l-4 border-${subtopic.color} shadow-lg`}
                      >
                        <span className="block text-center break-words line-clamp-2 text-xs">
                          {subtopic.text}
                        </span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

