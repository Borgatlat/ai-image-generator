'use client'

import { useState, useRef, useEffect } from 'react'
import { useChat } from 'ai/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent } from '@/components/ui/card'
import { Paperclip, X, Volume2, CircleStopIcon as Stop, Mic, MicOff, ArrowLeft } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'
import { useSupabase } from './providers/supabase-provider'
import { Flashcard } from '@/components/ui/flashcard'
import Link from 'next/link'
import { MindMap } from './MindMap'

const formatOptions = [
  { value: 'notes', label: 'Notes' },
  { value: 'flashcards', label: 'Flashcards' },
  { value: 'summary', label: 'Quick Summary' },
  { value: 'quiz', label: 'Quiz' },
  { value: 'mindmap', label: 'Mind Map' },
  { value: 'code', label: 'Code Example' },
  { value: 'humanizer', label: 'Humanizer' },
  { value: 'problem', label: 'Problem Solving' },
  { value: 'youtube', label: 'YouTube Video Summary' },
]

async function processFile(file: File): Promise<string> {
  const formData = new FormData()
  formData.append('file', file)

  const response = await fetch('/api/process-file', {
    method: 'POST',
    body: formData,
  })

  if (!response.ok) {
    throw new Error('File processing failed')
  }

  const { text } = await response.json()
  return text
}

export default function StudyNoteGenerator() {
  const [topic, setTopic] = useState('')
  const [format, setFormat] = useState('notes')
  const [file, setFile] = useState<File | null>(null)
  const [youtubeUrl, setYoutubeUrl] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const { supabase, session } = useSupabase()
  const [usageLimit, setUsageLimit] = useState({ notes: 0, uploads: 0 })
  const [isPremium, setIsPremium] = useState(false)
  const [isReading, setIsReading] = useState(false)
  const [speechSynthesis, setSpeechSynthesis] = useState<SpeechSynthesis | null>(null)
  const [isRecording, setIsRecording] = useState(false)
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null)

  const { messages, append, isLoading, reload } = useChat({
    api: '/api/generate-notes',
  })

  useEffect(() => {
    const fetchUsageLimit = async () => {
      if (session) {
        const { data, error } = await supabase
          .from('usage_limits')
          .select('*')
          .eq('user_id', session.user.id)
          .single()

        if (error) {
          console.error('Error fetching usage limit:', error)
          return
        }

        if (data) {
          setUsageLimit({ notes: data.notes, uploads: data.uploads })
          setIsPremium(data.is_premium)
        }
      }
    }

    fetchUsageLimit()
  }, [session, supabase])

  const updateUsageLimit = async (type: 'notes' | 'uploads') => {
    if (session) {
      const { data: usageLimitData, error } = await supabase
        .from('usage_limits')
        .update({ [type]: usageLimit[type] + 1 })
        .eq('user_id', session.user.id)
        .select()
        .single()

      if (error) {
        console.error('Error updating usage limit:', error)
        return
      }

      if (usageLimitData) {
        setUsageLimit({ ...usageLimit, [type]: usageLimitData[type] })
      }
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    setFile(file)
  }

  const removeFile = () => {
    setFile(null)
    fileInputRef.current?.setValue('')
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    if (isRecording) {
      recognition?.stop()
    } else {
      startRecording()
    }
  }

  const startRecording = () => {
    if (!recognition) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      setRecognition(new SpeechRecognition())
    }

    recognition?.onresult = (event) => {
      const transcript = event.results[0][0].transcript
      setTopic(topic + transcript)
    }

    recognition?.start()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const dailyNoteLimit = isPremium ? 30 : 10
    const dailyUploadLimit = isPremium ? 15 : 3

    if (session) {
      if (usageLimit.notes >= dailyNoteLimit) {
        toast({
          title: 'Usage Limit Reached',
          description: `You've reached your daily limit of ${dailyNoteLimit} notes. Upgrade to premium for more!`,
          variant: 'destructive',
        })
        return
      }

      if ((file || format === 'youtube') && usageLimit.uploads >= dailyUploadLimit) {
        toast({
          title: 'Upload Limit Reached',
          description: `You've reached your daily limit of ${dailyUploadLimit} file uploads or video summaries. Upgrade to premium for more!`,
          variant: 'destructive',
        })
        return
      }
    }

    let content = `Generate ${format} for the following topic: ${topic}. `
    
    if (format === 'youtube') {
      if (!youtubeUrl) {
        toast({
          title: 'Error',
          description: 'Please provide a YouTube URL.',
          variant: 'destructive',
        })
        return
      }

      try {
        const response = await fetch('/api/process-youtube', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ url: youtubeUrl }),
        })

        if (!response.ok) {
          throw new Error('Failed to process YouTube video')
        }

        const { title, description, summary } = await response.json()
        content += `\n\nSummarize the following YouTube video:\nTitle: ${title}\nDescription: ${description}\n\nVideo Summary:\n${summary}`
        
        if (session) {
          await updateUsageLimit('uploads')
        }
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to process the YouTube video. Please try again.',
          variant: 'destructive',
        })
        return
      }
    } else if (file) {
      try {
        const fileContent = await processFile(file)
        content += `\n\nUse the following file content as additional context:\n${fileContent}`
        
        if (session) {
          await updateUsageLimit('uploads')
        }
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to process the uploaded file. Please try again.',
          variant: 'destructive',
        })
        return
      }
    } else if (format === 'mindmap') {
      content += '\nPlease provide the mind map data in a JSON format that can be parsed and used with the MindMap component.'
    }

    content += '\n\nPlease provide expert-level explanations and include the latest information available by simulating web scraping.'

    append({
      role: 'user',
      content,
    })

    if (session) {
      await updateUsageLimit('notes')
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto bg-black rounded-2xl p-8 shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <Link href="/">
          <Button variant="ghost" className="text-white hover:bg-gray-800">
            <ArrowLeft className="mr-2" size={20} />
            Back
          </Button>
        </Link>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-white">Topic</label>
          <div className="relative">
            <Input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter your topic or question"
              className="w-full p-4 border-2 border-gray-700 rounded-xl focus:ring-white bg-black text-white pr-12"
              required
            />
            <Button
              type="button"
              onClick={toggleRecording}
              className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-2 rounded-full ${
                isRecording 
                  ? 'bg-red-500 hover:bg-red-600' 
                  : 'bg-purple-500 hover:bg-purple-600'
              }`}
            >
              {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Format</label>
            <Select value={format} onValueChange={setFormat}>
              <SelectTrigger className="w-full p-4 border-2 border-gray-700 rounded-xl bg-black text-white">
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                {formatOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {format === 'youtube' ? (
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">YouTube URL</label>
              <Input
                type="url"
                value={youtubeUrl}
                onChange={(e) => setYoutubeUrl(e.target.value)}
                placeholder="Enter YouTube video URL"
                className="w-full p-4 border-2 border-gray-700 rounded-xl focus:ring-white bg-black text-white"
              />
            </div>
          ) : (
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Upload File (Optional)</label>
              <div className="relative">
                <Input
                  type="file"
                  onChange={handleFileChange}
                  ref={fileInputRef}
                  className="hidden"
                  id="file-upload"
                />
                <label
                  htmlFor="file-upload"
                  className="flex items-center justify-center w-full p-4 border-2 border-gray-700 rounded-xl bg-black text-white cursor-pointer hover:bg-gray-900"
                >
                  <Paperclip className="w-5 h-5" />
                  {file ? file.name : 'Attach File'}
                </label>
                {file && (
                  <Button
                    type="button"
                    onClick={removeFile}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1"
                  >
                    <X size={16} />
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>

        <Button 
          type="submit" 
          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90 text-white p-6 rounded-xl text-lg"
          disabled={isLoading}
        >
          {isLoading ? 'Generating...' : 'Generate Content'}
        </Button>
      </form>

      {messages.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4 text-white">Preview</h2>
          <Card className="bg-gray-800 p-6 rounded-xl">
            {messages.map((message) => (
              <div key={message.id}>
                {message.role === 'assistant' && (
                  <>
                    {format === 'flashcards' ? (
                      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                        {message.content.split('\n').map((cardContent, index) => (
                          <Flashcard key={index} front={cardContent.split('|')[0]} back={cardContent.split('|')[1] || ''} />
                        ))}
                      </div>
                    ) : format === 'mindmap' ? (
                      <MindMap data={JSON.parse(message.content)} />
                    ) : (
                      <div className="prose prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: message.content }} />
                    )}
                  </>
                )}
              </div>
            ))}
          </Card>
        </div>
      )}
    </div>
  )
}

