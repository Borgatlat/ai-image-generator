'use client'

import { motion } from 'framer-motion'

export function AnimatedShapes() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Floating cube */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-32 h-32"
        animate={{
          y: [0, -20, 0],
          rotate: [0, 45, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <div className="w-full h-full relative transform preserve-3d">
          <div className="absolute inset-0 bg-gradient-to-br from-[#FF79C6] to-[#BD93F9] opacity-20 rounded-xl" />
        </div>
      </motion.div>

      {/* Floating sphere */}
      <motion.div
        className="absolute top-1/3 right-1/4 w-40 h-40"
        animate={{
          y: [0, 30, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <div className="w-full h-full bg-gradient-to-r from-[#8BE9FD] to-[#50FA7B] opacity-10 rounded-full blur-xl" />
      </motion.div>

      {/* Floating pyramid */}
      <motion.div
        className="absolute bottom-1/4 right-1/3 w-24 h-24"
        animate={{
          y: [0, -15, 0],
          rotate: [0, -30, 0],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <div className="w-full h-full bg-gradient-to-tr from-[#FFB86C] to-[#FF5555] opacity-15 transform rotate-45" />
      </motion.div>
    </div>
  )
}

