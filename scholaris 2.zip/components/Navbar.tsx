import Link from 'next/link'
import { Button } from './ui/button'
import { useSupabase } from './providers/supabase-provider'
import Image from 'next/image'

export default function Navbar() {
  const { session, supabase } = useSupabase()

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/50 backdrop-blur-xl border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-2">
            <div className="relative w-10 h-10">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pixlr-image-generator-496b3576-da9a-4977-9c65-4cf856d68488.png-9ciRWIiKfGhUwWOyaouVU5n6pFp5LT.webp"
                alt="Scholaris Logo"
                width={40}
                height={40}
                className="w-full h-full object-contain"
              />
            </div>
            <span className="text-xl font-bold text-white font-mono">
              Scholaris
            </span>
          </Link>
          
          <div className="flex items-center space-x-8">
            {session ? (
              <Button 
                onClick={() => supabase.auth.signOut()} 
                className="bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/10"
              >
                Sign Out
              </Button>
            ) : (
              <Link href="/signin">
                <Button 
                  className="bg-white hover:bg-gray-200 text-black"
                >
                  Sign In
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}

