import { google } from 'googleapis'
import ytdl from 'ytdl-core'
import fs from 'fs'
import path from 'path'
import { OpenAI } from 'openai'

const youtube = google.youtube({
  version: 'v3',
  auth: process.env.YOUTUBE_API_KEY
})

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export async function getVideoDetails(url: string) {
  const videoId = ytdl.getVideoID(url)
  const response = await youtube.videos.list({
    part: ['snippet'],
    id: [videoId]
  })

  const videoDetails = response.data.items[0].snippet
  return {
    title: videoDetails.title,
    description: videoDetails.description
  }
}

export async function downloadAudio(url: string): Promise<string> {
  const videoId = ytdl.getVideoID(url)
  const outputPath = path.join(process.cwd(), 'tmp', `${videoId}.mp3`)

  return new Promise((resolve, reject) => {
    ytdl(url, { filter: 'audioonly' })
      .pipe(fs.createWriteStream(outputPath))
      .on('finish', () => resolve(outputPath))
      .on('error', reject)
  })
}

export async function transcribeAudio(filePath: string): Promise<string> {
  const transcription = await openai.audio.transcriptions.create({
    file: fs.createReadStream(filePath),
    model: 'whisper-1'
  })

  return transcription.text
}

export async function summarizeText(text: string): Promise<string> {
  const chunks = splitText(text)
  let summary = ''

  for (const chunk of chunks) {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'You are an AI that summarizes videos into concise notes.' },
        { role: 'user', content: chunk }
      ]
    })

    summary += response.choices[0].message.content + '\n\n'
  }

  return summary.trim()
}

function splitText(text: string, maxTokens: number = 3000): string[] {
  const sentences = text.split('. ')
  const chunks: string[] = []
  let currentChunk = ''

  for (const sentence of sentences) {
    if (currentChunk.length + sentence.length <= maxTokens) {
      currentChunk += sentence + '. '
    } else {
      chunks.push(currentChunk.trim())
      currentChunk = sentence + '. '
    }
  }

  chunks.push(currentChunk.trim())
  return chunks
}

