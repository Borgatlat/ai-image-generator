'use client'

import { useState } from 'react'
import Auth from '@/components/Auth'
import { Loader2 } from 'lucide-react'

export default function SignIn() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md bg-white rounded-lg shadow-md p-8">
        <h1 className="text-2xl font-bold mb-6 text-center">Sign In / Sign Up</h1>
        {isLoading ? (
          <div className="flex justify-center items-center">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <Auth setIsLoading={setIsLoading} />
        )}
      </div>
    </div>
  )
}

