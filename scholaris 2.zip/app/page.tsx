import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { AnimatedShapes } from '@/components/AnimatedShapes'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-black text-white font-mono">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <AnimatedShapes />
        <div className="container relative mx-auto px-4 py-32">
          <div className="max-w-4xl">
            <h1 className="text-7xl font-bold mb-6 tracking-tight">
              Study smarter faster
            </h1>
            <p className="text-xl text-gray-400 mb-8 max-w-2xl font-mono">
              Intelligent, fast, and familiar, Scholaris is the best way to learn with AI.
            </p>
            <div className="flex gap-4">
              <Link href="/generate">
                <Button className="bg-white hover:bg-gray-200 text-black px-8 py-6 rounded-lg text-lg">
                  Get Started
                  <ArrowRight className="ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-[#111] rounded-xl p-8 border border-gray-800">
              <h3 className="text-2xl font-bold mb-4">Frontier Intelligence</h3>
              <p className="font-mono text-gray-400 mb-8">
                Powered by state-of-the-art AI models, delivering comprehensive study materials tailored to your needs.
              </p>
              <div className="h-48 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-transparent rounded-lg" />
                <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-br from-purple-500/30 to-pink-500/30 rounded-lg transform rotate-45" />
              </div>
            </div>

            <div className="bg-[#111] rounded-xl p-8 border border-gray-800">
              <h3 className="text-2xl font-bold mb-4">Private and Secure</h3>
              <p className="font-mono text-gray-400 mb-8">
                Your learning data stays private. Advanced encryption ensures your study materials remain confidential.
              </p>
              <div className="h-48 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-transparent rounded-lg" />
                <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/30 to-cyan-500/30 rounded-full" />
              </div>
            </div>

            <div className="bg-[#111] rounded-xl p-8 border border-gray-800">
              <h3 className="text-2xl font-bold mb-4">Feels Familiar</h3>
              <p className="font-mono text-gray-400 mb-8">
                Import your study materials and preferences in one click. Start learning immediately.
              </p>
              <div className="h-48 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 to-transparent rounded-lg" />
                <div className="absolute bottom-0 right-0 w-28 h-28 bg-gradient-to-br from-green-500/30 to-yellow-500/30 transform rotate-12" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Personalized Learning Section */}
      <section className="w-full py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="bg-[#111] rounded-xl p-8 border border-gray-800">
            <h3 className="text-2xl font-bold mb-4">Personalized Learning</h3>
            <p className="font-mono text-gray-400 mb-8">
              Tailor your study experience with customizable formats, difficulty levels, and learning styles to match your unique needs.
            </p>
            <div className="h-48 relative">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/20 to-transparent rounded-lg" />
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-500/30 to-orange-500/30 rounded-full transform rotate-45" />
            </div>
          </div>
        </div>
      </section>

      {/* Smart Features Section */}
      <section className="w-full py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-[#111] rounded-xl p-8 border border-gray-800 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500" />
              <h3 className="text-2xl font-bold mb-4">Smart Summaries</h3>
              <p className="font-mono text-gray-400">
                Generate concise, accurate summaries of any study material in seconds.
              </p>
            </div>

            <div className="bg-[#111] rounded-xl p-8 border border-gray-800 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-yellow-500 via-green-500 to-teal-500" />
              <h3 className="text-2xl font-bold mb-4">Flashcard Generation</h3>
              <p className="font-mono text-gray-400">
                Create interactive flashcards from your notes automatically.
              </p>
            </div>

            <div className="bg-[#111] rounded-xl p-8 border border-gray-800 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 via-blue-500 to-purple-500" />
              <h3 className="text-2xl font-bold mb-4">Multi-Format Support</h3>
              <p className="font-mono text-gray-400">
                Import PDFs, DOCs, and more. Export in any format you need.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 relative">
        <AnimatedShapes />
        <div className="container mx-auto px-4 text-center relative">
          <h2 className="text-5xl font-bold mb-8">
            Ready to transform your learning?
          </h2>
          <Link href="/generate">
            <Button className="bg-white hover:bg-gray-200 text-black px-8 py-6 rounded-lg text-lg">
              Try Scholaris Now
              <ArrowRight className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}

