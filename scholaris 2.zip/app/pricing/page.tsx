'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { useToast } from '@/components/ui/use-toast'
import { useSupabase } from '@/components/providers/supabase-provider'
import { loadStripe } from '@stripe/stripe-js'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default function Pricing() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const { session } = useSupabase()

  const handleSubscribe = async (priceId: string) => {
    if (!session) {
      router.push('/signin')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ price: priceId }),
      })

      const { sessionId } = await response.json()
      const stripe = await stripePromise

      const { error } = await stripe!.redirectToCheckout({ sessionId })

      if (error) {
        toast({
          title: 'Error',
          description: error.message,
          variant: 'destructive',
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'An unexpected error occurred.',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-4xl font-bold mb-8">Choose Your Plan</h1>
      <div className="flex flex-wrap justify-center gap-8">
        <Card className="w-80">
          <CardHeader>
            <CardTitle>Free Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside mb-4">
              <li>10 notes per day</li>
              <li>3 file uploads per day</li>
              <li>Basic note formats</li>
              <li>Copy and save notes</li>
            </ul>
            <p className="text-2xl font-bold mb-4">$0 / month</p>
          </CardContent>
          <CardFooter>
            <Button className="w-full" disabled>Current Plan</Button>
          </CardFooter>
        </Card>
        <Card className="w-80 border-2 border-primary">
          <CardHeader>
            <CardTitle>Premium Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside mb-4">
              <li>30 notes per day</li>
              <li>15 file uploads per day</li>
              <li>All note formats (including flashcards)</li>
              <li>Priority support</li>
            </ul>
            <p className="text-2xl font-bold mb-4">$9.99 / month</p>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={() => handleSubscribe('price_1234567890')}
              disabled={isLoading}
            >
              {isLoading ? 'Processing...' : 'Upgrade Now'}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

