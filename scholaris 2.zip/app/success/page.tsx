'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/use-toast'

export default function Success() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const checkSession = async () => {
      const sessionId = new URLSearchParams(window.location.search).get('session_id')
      
      if (sessionId) {
        try {
          const response = await fetch(`/api/check-session?session_id=${sessionId}`)
          const data = await response.json()

          if (data.success) {
            toast({
              title: 'Subscription Successful',
              description: 'Thank you for subscribing to Scholaris Premium!',
            })
          } else {
            throw new Error('Invalid session')
          }
        } catch (error) {
          toast({
            title: 'Error',
            description: 'There was a problem confirming your subscription.',
            variant: 'destructive',
          })
        }
      } else {
        toast({
          title: 'Error',
          description: 'Invalid session.',
          variant: 'destructive',
        })
      }

      setIsLoading(false)
    }

    checkSession()
  }, [toast])

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-4xl font-bold mb-8">Thank You for Your Purchase!</h1>
      <p className="text-xl mb-8">Your subscription to Scholaris Premium is now active.</p>
      <Button onClick={() => router.push('/')}>Start Using Scholaris</Button>
    </div>
  )
}

