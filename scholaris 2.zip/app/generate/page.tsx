import StudyNoteGenerator from '@/components/StudyNoteGenerator'
import { AnimatedShapes } from '@/components/AnimatedShapes'

export default function GeneratePage() {
  return (
    <div className="min-h-screen bg-black text-white font-mono relative overflow-hidden">
      <AnimatedShapes />
      <div className="container mx-auto px-4 py-24 relative z-10">
        <h1 className="text-5xl font-bold mb-12 text-center bg-gradient-to-r from-purple-500 to-pink-500 text-transparent bg-clip-text">
          Transform Your Learning
        </h1>
        <StudyNoteGenerator />
      </div>
    </div>
  )
}

