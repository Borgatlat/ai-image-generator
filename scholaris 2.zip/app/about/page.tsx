export default function About() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-4xl font-bold mb-8">About Scholaris</h1>
      <div className="max-w-2xl text-center">
        <p className="mb-4">
          Scholaris is an AI-powered study notes generator designed to help students and lifelong learners quickly grasp complex topics. Our advanced AI technology creates concise, personalized notes tailored to your specific needs and learning level.
        </p>
        <p className="mb-4">
          Whether you're a high school student, college undergraduate, or advanced learner, Scholaris adapts to your requirements, providing bullet points or paragraph summaries to suit your learning style.
        </p>
        <p>
          Our mission is to make learning more efficient and accessible for everyone. With Scholaris, you can save time on note-taking and focus on understanding and retaining information.
        </p>
      </div>
    </div>
  )
}

