import { NextResponse } from 'next/server'
import { getVideoDetails, downloadAudio, transcribeAudio, summarizeText } from '@/lib/youtube-utils'

export async function POST(req: Request) {
  try {
    const { url } = await req.json()
    
    if (!url) {
      return NextResponse.json({ error: 'No YouTube URL provided' }, { status: 400 })
    }

    // Get video details
    const videoDetails = await getVideoDetails(url)

    // Download audio
    const audioPath = await downloadAudio(url)

    // Transcribe audio
    const transcription = await transcribeAudio(audioPath)

    // Summarize transcription
    const summary = await summarizeText(transcription)

    return NextResponse.json({ 
      title: videoDetails.title,
      description: videoDetails.description,
      summary 
    })
  } catch (error) {
    console.error('YouTube processing error:', error)
    return NextResponse.json(
      { error: 'Error processing YouTube video', details: error.message },
      { status: 500 }
    )
  }
}

