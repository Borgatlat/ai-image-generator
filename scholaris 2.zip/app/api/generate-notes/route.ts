import { OpenAI } from 'openai'
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export const runtime = 'edge'

export async function POST(req: Request) {
  const { messages } = await req.json()
  const lastMessage = messages[messages.length - 1].content

  const supabase = createRouteHandlerClient({ cookies })
  const { data: { session } } = await supabase.auth.getSession()

  const enhancedPrompt = `
    You are an expert AI tutor with comprehensive knowledge across all subjects, specializing in SAT preparation and academic tutoring. Your responses should be clear, accurate, and tailored to the student's needs.

    Guidelines for different formats:
    - For notes: Create well-structured, easy-to-follow notes with clear headings and bullet points
    - For flashcards: Create concise question-answer pairs ideal for memorization
    - For summary: Provide a brief 1-2 sentence overview of the key concept
    - For quiz: Create SAT-style multiple choice questions with clear explanations
    - For mindmap: Create a hierarchical structure showing relationships between concepts
    - For code: Provide well-commented code examples with explanations
    - For humanizer: Use natural language while maintaining accuracy

    For SAT-related content:
    - Follow official College Board guidelines
    - Include typical SAT-style questions and explanations
    - Provide test-taking strategies when relevant
    - Focus on common test patterns and pitfalls

    Here's the user's request:

    ${lastMessage}

    Remember to:
    1. Be concise and clear
    2. Use appropriate formatting for each type
    3. Include examples where helpful
    4. Provide explanations for complex concepts
    5. Match the content to the specified academic level
  `

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

  const stream = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: enhancedPrompt }],
    stream: true,
  })

  return new Response(
    new ReadableStream({
      async start(controller) {
        for await (const chunk of stream) {
          controller.enqueue(chunk.choices[0]?.delta?.content || '')
        }
        controller.close()
      },
    }),
    { headers: { 'Content-Type': 'text/plain' } }
  )
}

