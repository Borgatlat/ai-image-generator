import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
})

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(req: Request) {
  const body = await req.text()
  const signature = headers().get('stripe-signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
  } catch (err) {
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 })
  }

  const supabase = createRouteHandlerClient({ cookies })

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session
      
      // Update user's premium status in Supabase
      await supabase
        .from('user_plans')
        .upsert({
          user_id: session.client_reference_id,
          is_premium: true,
          stripe_customer_id: session.customer as string,
          subscription_id: session.subscription as string,
        })

      // Reset usage limits
      await supabase
        .from('usage_limits')
        .upsert({
          user_id: session.client_reference_id,
          notes: 0,
          uploads: 0,
        })

      break
    }
    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription
      
      // Update user's premium status in Supabase
      await supabase
        .from('user_plans')
        .update({ is_premium: false })
        .eq('subscription_id', subscription.id)

      break
    }
  }

  return NextResponse.json({ received: true })
}

