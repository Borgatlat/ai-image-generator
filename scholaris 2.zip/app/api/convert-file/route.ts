import { NextResponse } from 'next/server'
import { PDFDocument } from 'pdf-lib'
import mammoth from 'mammoth'
import xlsx from 'xlsx'

export const config = {
  api: {
    bodyParser: false,
  },
}

export async function POST(req: Request) {
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 })
    }

    const buffer = await file.arrayBuffer()
    let text = ''

    try {
      switch (file.type) {
        case 'application/pdf':
          text = await convertPdf(buffer)
          break
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          text = await convertDocx(buffer)
          break
        case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
          text = await convertXlsx(buffer)
          break
        case 'text/plain':
          text = await file.text()
          break
        case 'text/csv':
          text = await file.text()
          break
        case 'application/json':
          text = await file.text()
          break
        default:
          if (file.name.endsWith('.md')) {
            text = await file.text()
          } else {
            return NextResponse.json(
              { error: 'Unsupported file type' },
              { status: 400 }
            )
          }
      }

      return NextResponse.json({ text })
    } catch (error) {
      console.error('File conversion error:', error)
      return NextResponse.json(
        { error: 'Error processing file content' },
        { status: 500 }
      )
    }
  } catch (error) {
    console.error('Request handling error:', error)
    return NextResponse.json(
      { error: 'Error handling file upload' },
      { status: 500 }
    )
  }
}

async function convertPdf(buffer: ArrayBuffer): Promise<string> {
  try {
    const pdfDoc = await PDFDocument.load(buffer)
    const pages = pdfDoc.getPages()
    let text = ''
    
    for (const page of pages) {
      const pageText = await page.getText()
      text += pageText + '\n\n'
    }
    
    return text.trim()
  } catch (error) {
    console.error('PDF conversion error:', error)
    throw new Error('Failed to convert PDF')
  }
}

async function convertDocx(buffer: ArrayBuffer): Promise<string> {
  try {
    const result = await mammoth.extractRawText({ arrayBuffer: buffer })
    return result.value.trim()
  } catch (error) {
    console.error('DOCX conversion error:', error)
    throw new Error('Failed to convert DOCX')
  }
}

async function convertXlsx(buffer: ArrayBuffer): Promise<string> {
  try {
    const workbook = xlsx.read(new Uint8Array(buffer), { type: 'array' })
    let text = ''
    
    workbook.SheetNames.forEach(sheetName => {
      const sheet = workbook.Sheets[sheetName]
      text += `Sheet: ${sheetName}\n${xlsx.utils.sheet_to_csv(sheet)}\n\n`
    })
    
    return text.trim()
  } catch (error) {
    console.error('XLSX conversion error:', error)
    throw new Error('Failed to convert XLSX')
  }
}

