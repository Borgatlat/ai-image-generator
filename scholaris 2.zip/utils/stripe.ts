import { loadStripe } from '@stripe/stripe-js'

export async function redirectToCheckout(priceId: string) {
  try {
    const response = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ price: priceId }),
    })

    const { sessionId } = await response.json()
    const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)
    
    if (!stripe) {
      throw new Error('Failed to load Stripe')
    }

    const { error } = await stripe.redirectToCheckout({ sessionId })
    
    if (error) {
      throw error
    }
  } catch (error) {
    console.error('Error:', error)
    throw error
  }
}

