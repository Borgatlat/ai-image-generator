import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })
  const { data: { session } } = await supabase.auth.getSession()

  // If user is not signed in and the current path requires auth,
  // redirect to /signin and store the current path in redirectTo
  if (!session && req.nextUrl.pathname.startsWith('/generate')) {
    const redirectUrl = new URL('/signin', req.url)
    redirectUrl.searchParams.set('redirectTo', req.nextUrl.pathname)
    return NextResponse.redirect(redirectUrl)
  }

  // Update session if it exists
  if (session) {
    res.headers.set('x-user-id', session.user.id)
  }

  return res
}

export const config = {
  matcher: ['/generate/:path*']
}

